﻿namespace RuleRunner.Models;
public class AppSettings
{
    public ConnectionStrings ConnectionStrings { get; set; }
    public Qbe Qbe { get; set; }
    public InRuleProfessionalServices InRuleProfessionalServices { get; set; }
    public Timer Timer { get; set; }
    public string JsonDirectory { get; set; }
    public string ResultDirectory { get; set; }
    public int MaxRetries { get; set; }
    public int InRuleMessageSize { get; set; }
    public int RequestsAtOneTime { get; set; }
}

public class InRuleProfessionalServices
{
    public string ExecutionServiceUrl { get; set; }
    public string ApiKey { get; set; }
    public string? Label { get; set; }
    public int? Revision { get; set; }
}

public class ConnectionStrings
{
    public string Default { get; set; }
}

public class Development
{
    public string ExecutionServiceUrl { get; set; }
    public string ApiKey { get; set; }
}

public class Qbe
{
    public string RuleApplicationName { get; set; }
    public string EntityName { get; set; }
    public string? Label { get; set; }
    public int? Revision { get; set; }
}

public class Timer
{
    public int Milliseconds { get; set; }
    public int Seconds { get; set; }
}
