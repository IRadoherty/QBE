﻿namespace RuleRunner.Models;

public class ExecutionResponse
{
    public ActiveNotification[]? ActiveNotifications { get; set; }
    public ActiveValidation[]? ActiveValidations { get; set; }
    public string? EntityState { get; set; }
    public bool HasRuntimeErrors { get; set; }
    public string? Overrides { get; set; }
    public Parameters? Parameters { get; set; }
    public string RequestId { get; set; }
    public RuleExecutionLog? RuleExecutionLog { get; set; }
    public string? RuleSessionState { get; set; }
    public string SessionId { get; set; }
}

public class ActiveNotification
{
    public string? ElementId { get; set; }
    public bool IsActive { get; set; }
    public string? Message { get; set; }
    public string? NotificationType { get; set; }
}
public class ActiveValidation
{
    public string? ElementIdentifier { get; set; }
    public string? InvalidMessageText { get; set; }
    public bool IsValid { get; set; }
    public Reason[]? Reasons { get; set; }
}

public class Reason
{
    public string? FiringRuleId { get; set; }
    public string? MessageText { get; set; }
}

public class RuleExecutionLog
{
    //public Message[]? Messages { get; set; }
    public dynamic? Messages { get; set; }
    public long TotalEvaluationCycles { get; set; }
    public string? TotalExecutionTime { get; set; }
    public int TotalTraceFrames { get; set; }
}

//public class Message
//{
//    public string? Description { get; set; }
//    public int ChangeType { get; set; }
//    public int CollectionCount { get; set; }
//    public string? CollectionId { get; set; }
//    public string? MemberId { get; set; }
//    public int MemberIndex { get; set; }
//}
public class Parameters
{
    public string Name { get; set; }
    public string Value { get; set; }
}
