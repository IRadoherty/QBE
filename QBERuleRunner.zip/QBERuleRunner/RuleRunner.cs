﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;
using RuleRunner.Models;
using EntityStates = System.Collections.Generic.KeyValuePair<int, RuleRunner.Models.EntityState>;

namespace RuleRunner;

public class RuleRunner
{
    public static AppSettings AppSettings = Program.AppSettings;

    private readonly ILogger<RuleRunner> _logger;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly AsyncRetryPolicy<HttpResponseMessage> _retryPolicy;
    private int _inRuleMessageSize = AppSettings.InRuleMessageSize;
    private readonly SemaphoreSlim _semaphore = new(AppSettings.RequestsAtOneTime, AppSettings.RequestsAtOneTime);
    private ConcurrentQueue<EntityStates> _messages = new();

    public RuleRunner(ILogger<RuleRunner> logger, IHttpClientFactory httpClientFactory)
    {
        _logger = logger;
        _httpClientFactory = httpClientFactory;
        _retryPolicy = Policy<HttpResponseMessage>.Handle<HttpRequestException>().RetryAsync(AppSettings.MaxRetries);
    }

    public async Task StartRuleRunner()
    {
        try
        {
            var elapsedTime = Stopwatch.StartNew();
            var directories = GetDirectory();
            foreach (var jsonFile in directories.Json)
            {
                var json = await File.ReadAllTextAsync(jsonFile.FullName);
                var jsonData = JsonConvert.DeserializeObject<IsoArray>(json);
                IsoData[]? isoData = jsonData.Iso;
                List<Task> tasks = new();
                int batchCount = 0, index = 0;
                while (index < jsonData.Iso.Length)
                {
                    batchCount++;
                    int remainingElements = jsonData.Iso.Length - index;
                    tasks.Add(remainingElements >= _inRuleMessageSize
                        ? ApplyRules(isoData?[index..(index + _inRuleMessageSize)], batchCount)
                        : ApplyRules(isoData?[index..(index + remainingElements)], batchCount));
                    index += _inRuleMessageSize;

                }

                await Task.WhenAll(tasks);

                List<EntityState> entityStates = new();
                while (_messages.TryDequeue(out var msg))
                {
                    entityStates.Add(msg.Value);
                }
                var outputData = JsonConvert.SerializeObject(entityStates);
                await File.WriteAllTextAsync(AppSettings.ResultDirectory + jsonFile.Name.Replace(".json", "") + "_result.json", outputData);
            }

            elapsedTime.Stop();
            _logger.LogInformation("{RuleRunner} completed in {Elapsed}", nameof(RuleRunner), elapsedTime.Elapsed);

        }
        catch (Exception e)
        {
            _logger.LogInformation("{RuleRunner} encountered an error: {Message}", nameof(RuleRunner), e.Message);
        }
    }


    public async Task ApplyRules(IsoData[]? isoData, int batchCount)
    {
        try
        {
            await _semaphore.WaitAsync();
            _logger.LogInformation("Started apply rules request");
            IsoArray isoArray = new() { Iso = isoData };
            var applyRulesRequest = CreateApplyRulesRequest(JsonConvert.SerializeObject(isoArray));
            var requestJson = JsonConvert.SerializeObject(applyRulesRequest);
            var httpClient = _httpClientFactory.CreateClient("ApplyRules");
            httpClient.Timeout = TimeSpan.FromSeconds(300);
            var content = new StringContent(requestJson, Encoding.UTF8, "application/json");
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            var response = await _retryPolicy.ExecuteAsync(async () =>
                await httpClient.PostAsync(AppSettings.InRuleProfessionalServices.ExecutionServiceUrl, content));
            var responseString = await response.Content.ReadAsStringAsync();
            var executionResponse = JsonConvert.DeserializeObject<ExecutionResponse>(responseString);
            var entityState = JsonConvert.DeserializeObject<EntityState>(executionResponse.EntityState);
            if (entityState is not null)
            {
                _messages.Enqueue(new EntityStates(batchCount, entityState));
                _logger.LogInformation("Completed ApplyRules request");
            }
            else
            {
                _logger.LogInformation("Found null response for case and did not add to queue");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError("Error executing batch: {Message}", ex.Message);
        }
        finally
        {
            _semaphore.Release();
        }
    }
    private static ApplyRulesRequest CreateApplyRulesRequest(string entityState)
    {
        //var label = AppSettings.InRuleProfessionalServices.Label;
        //if (label is null or "")
        //    label = null;

        return new ApplyRulesRequest
        {
            RuleApp = new RuleApp
            {
                RepositoryRuleAppRevisionSpec = new RepositoryRuleAppRevisionSpec
                {
                    RuleApplicationName = AppSettings.Qbe.RuleApplicationName
                    //Label = label,
                    //Revision = AppSettings.Qbe.Revision
                }
            },
            EntityName = AppSettings.Qbe.EntityName,
            EntityState = entityState
        };
    }
    //public async Task WarmUpExecutionService(IsoData isoData)
    //{
    //    IsoArray isoArray = new() { Iso = isoData };
    //    var httpClient = _httpClientFactory.CreateClient("ApplyRules");
    //    var applyRulesRequest = CreateApplyRulesRequest(JsonConvert.SerializeObject(isoArray));
    //    var requestJson = JsonConvert.SerializeObject(applyRulesRequest);
    //    var content = new StringContent(requestJson, Encoding.UTF8, "application/json");
    //    content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
    //    await httpClient.PostAsync(AppSettings.InRuleProfessionalServices.ExecutionServiceUrl, content);
    //}

    //private async Task CreateCompanyWithStream()
    //{
    //    var companyForCreation = new CompanyForCreationDto
    //    {
    //        Name = "Eagle IT Ltd.",
    //        Country = "USA",
    //        Address = "Eagle IT Street 289"
    //    };

    //    var ms = new MemoryStream();
    //    await JsonSerializer.SerializeAsync(ms, companyForCreation);
    //    ms.Seek(0, SeekOrigin.Begin);

    //    var request = new HttpRequestMessage(HttpMethod.Post, "companies");
    //    request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

    //    using (var requestContent = new StreamContent(ms))
    //    {
    //        request.Content = requestContent;
    //        requestContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

    //        using (var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead))
    //        {
    //            response.EnsureSuccessStatusCode();

    //            var content = await response.Content.ReadAsStreamAsync();
    //            var createdCompany = await JsonSerializer.DeserializeAsync<CompanyDto>(content, _options);
    //        }
    //    }
    //}
    public Directories GetDirectory()
    {
        var directories = new Directories();
        var jsonDirectory = new DirectoryInfo(AppSettings.JsonDirectory);
        directories.Json = jsonDirectory.GetFiles("*.json*");

        return directories;
    }
    public class Directories
    {
        public FileInfo[] Json;
    }
}
