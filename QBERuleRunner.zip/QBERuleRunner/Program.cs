﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RuleRunner.Models;
using Serilog;
using Serilog.Events;

namespace RuleRunner;
internal class Program
{
    public static AppSettings AppSettings { get; set; }
    private static async Task Main()
    {
        try
        {
            IConfiguration config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .AddEnvironmentVariables()
                .Build();

            AppSettings = config.GetRequiredSection("AppSettings").Get<AppSettings>();

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(config)
                .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                .CreateLogger();

            using var host = Host.CreateDefaultBuilder()
                .ConfigureServices((services) =>
                {
                    services.AddSingleton<RuleRunner>();
                    services.AddHttpClient("ExecuteRuleSet", client =>
                    {
                        client.BaseAddress = new Uri(AppSettings.InRuleProfessionalServices.ExecutionServiceUrl);
                        client.DefaultRequestHeaders.Add("Accept", "application/json");
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization",
                            AppSettings.InRuleProfessionalServices.ApiKey);
                    });
                    services.AddHttpClient("ApplyRules", client =>
                    {
                        client.BaseAddress = new Uri(AppSettings.InRuleProfessionalServices.ExecutionServiceUrl);
                        client.DefaultRequestHeaders.Add("Accept", "application/json");
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization",
                            AppSettings.InRuleProfessionalServices.ApiKey);
                    });
                    services.AddHttpClient("ExecuteDecision", client =>
                    {
                        client.BaseAddress = new Uri(AppSettings.InRuleProfessionalServices.ExecutionServiceUrl);
                        client.DefaultRequestHeaders.Add("Accept", "application/json");
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization",
                            AppSettings.InRuleProfessionalServices.ApiKey);
                    });
                })
                .UseSerilog()
                .Build();

            var startTime = DateTime.UtcNow;
            Log.Logger.Information("{RuleRunner} Has Started - {startTime}", nameof(RuleRunner), startTime);

            //await host.RunAsync();

            await host.StartAsync();

            var ruleRunner = host.Services.GetRequiredService<RuleRunner>();
            await ruleRunner.StartRuleRunner();

            await host.WaitForShutdownAsync();
            Log.Logger.Information("{RuleRunner} Has Shutdown: {DateTime} Up time: {elapsedTime} minutes.",
                nameof(RuleRunner), DateTime.UtcNow, Math.Round(((DateTime.UtcNow - startTime).TotalMinutes), 2));
        }
        catch (Exception e)
        {
            Log.Logger.Error(e, "{RuleRunner} encountered an error: {Message}", nameof(RuleRunner), e.Message);
        }
    }
}
