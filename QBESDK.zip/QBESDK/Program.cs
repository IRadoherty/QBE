﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Events;

namespace QBESDK;
internal class Program
{
    private static async Task Main()
    {
        try
        {
            IConfiguration config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .AddEnvironmentVariables()
                .Build();

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(config)
                .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                .CreateLogger();

            using var host = Host.CreateDefaultBuilder()
                .ConfigureServices((services) =>
                {
                    services.AddSingleton<RuleRunner>();
                    services.AddSingleton<SplitFiles>();
                })
                .UseSerilog()
                .Build();

            var startTime = DateTime.UtcNow;
            Log.Logger.Information("{RuleRunner} started at {startTime}", nameof(RuleRunner), startTime);

            await host.StartAsync();

            var ruleRunner = host.Services.GetRequiredService<RuleRunner>();
            await ruleRunner.StartRuleRunner();

            //var splitFiles = host.Services.GetRequiredService<SplitFiles>();
            //await splitFiles.StartRuleRunner();

            await host.WaitForShutdownAsync();
            Log.Logger.Information("{RuleRunner} shutdown at {DateTime} Up time: {elapsedTime} minutes.",
                nameof(RuleRunner), DateTime.UtcNow, Math.Round(((DateTime.UtcNow - startTime).TotalMinutes), 2));
        }
        catch (Exception e)
        {
            Log.Logger.Error(e, "{RuleRunner} encountered an error: {Message}", nameof(RuleRunner), e.Message);
        }
    }
}
