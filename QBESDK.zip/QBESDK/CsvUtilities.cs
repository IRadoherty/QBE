﻿//using CsvHelper;
//using CsvHelper.Configuration;
//using Microsoft.Extensions.Configuration;
//using System.Globalization;

//namespace QBESDK;
//public interface ICsvUtilities
//{
//    void WriteCsvFile(string csvFileName, List<T> csvData);
//}

//public class CsvUtilities : ICsvUtilities
//{
//    private readonly IConfiguration _config;

//    public CsvUtilities(IConfiguration config)
//    {
//        _config = config;
//    }

//    public void WriteCsvFile(string csvFileName, List<T> csvData)
//    {
//        var configPersons = new CsvConfiguration(CultureInfo.InvariantCulture)
//        {
//            HasHeaderRecord = false
//        };
//        using var writer = new StreamWriter(_config.GetValue<string>("CsvFolder") + csvFileName);
//        using var csv = new CsvWriter(writer, configPersons);
//        csv.WriteRecords(csvData);
//    }
//}
