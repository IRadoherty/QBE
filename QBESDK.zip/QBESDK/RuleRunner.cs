﻿using InRule.Runtime;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace QBESDK;

public class RuleRunner
{
    private readonly IConfiguration _config;
    //private readonly ICsvUtilities _csvUtilities;
    private readonly ILogger<RuleRunner> _logger;
    public RuleRunner(IConfiguration config, ILogger<RuleRunner> logger) //ICsvUtilities csvUtilities,
    {
        _config = config;
        _logger = logger;
        //_csvUtilities = csvUtilities;
    }
    public async Task StartRuleRunner()
    {
        try
        {
            var elapsedTime = Stopwatch.StartNew();
            var directories = GetDirectory();
            var ruleAppRef = new CatalogRuleApplicationReference("https://road-dev-catalog.staging.inrulecloud.com/service.svc/core",
                "ISO_QBE", "adoherty", "password", "LIVE", true);
            ruleAppRef.SetRefresh(TimeSpan.FromHours(1)); // turn refresh off while running to keep rule app from being updated
            _logger.LogInformation("Pulled rule app from catalog");
            foreach (var jsonFile in directories.Json)
            {
                var json = await File.ReadAllTextAsync(jsonFile.FullName);
                _logger.LogInformation("Loaded json file: {Name}", jsonFile.Name);
                //var jsonData = JsonConvert.DeserializeObject<IsoArray>(json);
                //var ruleAppRef = new CatalogRuleApplicationReference(_config.GetValue<string>("CatalogUri"),
                //_config.GetValue<string>("RuleAppName"), _config.GetValue<string>("UserName"),
                //_config.GetValue<string>("Password"), _config.GetValue<string>("Label"),
                //true);

                //_logger.LogInformation("Creating session..");
                using var session = new RuleSession(ruleAppRef);
                //_logger.LogInformation("Creating entity..");
                var entity = session.CreateEntity(_config.GetValue<string>("EntityName"), json, EntityStateType.Json);
                //_logger.LogInformation("Executing rules..");
                //session.ApplyRules();
                await session.ApplyRulesAsync();
                //_logger.LogInformation("Getting json..");
                var result = entity.GetJson();
                _logger.LogInformation("Writing json file..");
                //var jsonResult = JsonConvert.DeserializeObject<IsoFinalEntityState>(result);
                await File.WriteAllTextAsync(_config.GetValue<string>("JsonOutputFolder") + 
                        jsonFile.Name.Replace(".json", "") + "_result.json", result);
            }

            elapsedTime.Stop();
            _logger.LogInformation("{RuleRunner} completed in {Time}", nameof(RuleRunner), elapsedTime.Elapsed);
        }
        catch (Exception e)
        {
            _logger.LogInformation("{RuleRunner} encountered an error: {Message}", nameof(RuleRunner), e.Message);
        }
    }
    public Directories GetDirectory()
    {
        var directories = new Directories();
        var jsonDirectory = new DirectoryInfo(_config.GetValue<string>("JsonInputFolder"));
        directories.Json = jsonDirectory.GetFiles("*.json*");
        return directories;
    }
    public class Directories
    {
        public FileInfo[] Json;
    }
}
