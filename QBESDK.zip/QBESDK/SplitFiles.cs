﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RuleRunner.Models;
using System;

namespace QBESDK;
public class SplitFiles
{
    private readonly IConfiguration _config;
    private readonly ILogger<RuleRunner> _logger;
    public SplitFiles(IConfiguration config, ILogger<RuleRunner> logger)
    {
        _config = config;
        _logger = logger;
    }
    public async Task StartRuleRunner()
    {
        var directories = GetDirectory();
        foreach (var jsonFile in directories.Json)
        {
            var json = await File.ReadAllTextAsync(jsonFile.FullName);
            var jsonData = JsonConvert.DeserializeObject<IsoArray>(json);

            int chunkSize = 50;
            List<IsoData[]> outputChunks = SplitArray(jsonData.Iso, chunkSize);
            int i = 0;
            foreach (var jsonResult in outputChunks.Select(chunk => 
                         new IsoArray { Iso = chunk }).Select(JsonConvert.SerializeObject))
            {
                await File.WriteAllTextAsync(_config.GetValue<string>("JsonOutputFolder") +
                                             jsonFile.Name.Replace(".json", "") + $"_result{i}.json", jsonResult);
                ++i;
            }
            //List<IsoArray> chunks = new ();
            //int chunkSize = 250;
            //for (int i = 0; i < jsonData.Iso.Length; i += chunkSize)
            //{
            //    int size = Math.Min(chunkSize, jsonData.Iso.Length - i);
            //    var chunk = new IsoArray[size];
            //    Array.Copy(jsonData.Iso, i, chunk, 0, size);
            //    //var jsonResult = JsonConvert.DeserializeObject<IsoFinalEntityState>(chunk.ToString());
            //    await File.WriteAllTextAsync(_config.GetValue<string>("JsonOutputFolder") +
            //                                 jsonFile.Name.Replace(".json", "") + $"_result{i}.json", chunk.ToString());
            //    //chunks.Add(chunk);
            //    string check = "";
            //}
        }
    }
    public static List<T[]> SplitArray<T>(T[] array, int chunkSize)
    {
        List<T[]> chunks = new ();
        for (int i = 0; i < array.Length; i += chunkSize)
        {
            int size = Math.Min(chunkSize, array.Length - i);
            T[] chunk = new T[size];
            Array.Copy(array, i, chunk, 0, size);
            chunks.Add(chunk);
        }
        return chunks;
    }
    public Directories GetDirectory()
        {
            var directories = new Directories();
            var jsonDirectory = new DirectoryInfo(_config.GetValue<string>("JsonInputFolder"));
            directories.Json = jsonDirectory.GetFiles("*.json*");
            return directories;
        }
    
    public class Directories
    {
        public FileInfo[] Json;
    }
}
