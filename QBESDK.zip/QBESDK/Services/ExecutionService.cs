﻿//using InRule.Runtime;

//namespace QBESDK.Services;

//public interface IExecutionService
//{
//    Task<string> ApplyRules();
//}

//public class ExecutionService
//{
//    public async Task<string> ApplyRules(string input, string entityName, CatalogRuleApplicationReference ruleAppRef)
//    {
//        try
//        {
//            var session = new RuleSession(ruleAppRef);
//            var entity = session.CreateEntity(entityName, input, EntityStateType.Json);
//            await session.ApplyRulesAsync();
//            return entity.GetJson();
//        }
//        catch (Exception ex)
//        {
//            return ex.Message;
//        }
//    }
//}

