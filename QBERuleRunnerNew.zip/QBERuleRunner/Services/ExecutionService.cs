﻿using System.Collections.Concurrent;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;
using QBERuleRunner.Models;

namespace QBERuleRunner.Services;

public interface IExecutionService
{
    Task ApplyRules(IReadOnlyList<Iso> isoData, int index, int rangeSize);
    Task WarmUpExecutionService(Iso isoData);
    Task WriteOutputFiles(FileSystemInfo jsonFile);
}

public class ExecutionService : IExecutionService
{
    private readonly AppSettings _appSettings;
    private readonly HttpClient _httpClient;
    private readonly ILogger<ExecutionService> _logger;
    private readonly ConcurrentQueue<PolicyInfo> _policyQueue;
    private readonly IReport _report;
    private readonly AsyncRetryPolicy<HttpResponseMessage> _retryPolicy;
    private readonly SemaphoreSlim _semaphore;

    public ExecutionService(ILogger<ExecutionService> logger, IHttpClientFactory httpClientFactory, IReport report) 
    {
        _logger = logger;
        _appSettings = Program.AppSettings;
        _semaphore = new SemaphoreSlim(_appSettings.MaxRequestsAtOneTime, _appSettings.MaxRequestsAtOneTime);
        _policyQueue = new ConcurrentQueue<PolicyInfo>();
        _retryPolicy = Policy<HttpResponseMessage>.Handle<HttpRequestException>().RetryAsync(_appSettings.MaxRetries);
        _httpClient = httpClientFactory.CreateClient("ApplyRules");
        _report = report;
    }

    public async Task ApplyRules(IReadOnlyList<Iso> isoData, int index, int rangeSize)
    {
        await _semaphore.WaitAsync();
        _logger.LogInformation($"Applying rules to batch {Variables.BatchCount} for run {Variables.RunCount} " +
                               $"on ISO records {index} to {index + rangeSize - 1}");
        try
        {
            IsoArray entityState = new() { Iso = isoData.ToArray() };
            var applyRulesRequest = CreateApplyRulesRequest(JsonConvert.SerializeObject(entityState));
            var content = new StringContent(JsonConvert.SerializeObject(applyRulesRequest), Encoding.UTF8, "application/json");
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            var response = await _retryPolicy.ExecuteAsync(async () =>
                await _httpClient.PostAsync(_httpClient.BaseAddress, content));
            
            var executionResponse = JsonConvert.DeserializeObject<ExecutionResponse>(await response.Content.ReadAsStringAsync());
            if (executionResponse is not null)
            {
                if (executionResponse.HasRuntimeErrors)
                {
                    Variables.RuntimeErrors = executionResponse.HasRuntimeErrors;
                    await SaveRequestAndResponseFiles(applyRulesRequest, executionResponse);
                }
                if (response.IsSuccessStatusCode)
                {
                    ProcessExecutionResponse(executionResponse);
                    _logger.LogInformation($"Completed ApplyRules request for batch {Variables.BatchCount} run {Variables.RunCount}");
                    _report.LogToReport(isoData, PolicyStatus.Completed, executionResponse.HasRuntimeErrors);
                    return;
                }
            }

            LogAndReportFailure(response.StatusCode, isoData, true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "An error occurred while executing the ApplyRules request for batch {BatchCount} run {RunCount}",
                Variables.BatchCount, Variables.RunCount);
            _report.LogToReport(isoData, PolicyStatus.Failed, true);
        }
        finally
        {
            _semaphore.Release();
        }
    }

    public async Task WarmUpExecutionService(Iso isoData)
    {
        IsoArray entityState = new() { Iso = new[] { isoData } };
        var applyRulesRequest = CreateApplyRulesRequest(JsonConvert.SerializeObject(entityState));
        var content = new StringContent(JsonConvert.SerializeObject(applyRulesRequest), Encoding.UTF8, "application/json");
        content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        var response = await _httpClient.PostAsync(_httpClient.BaseAddress, content);
        if (!response.IsSuccessStatusCode)
        {
            var responseString = await response.Content.ReadAsStringAsync();
            _logger.LogInformation("Error during warmup:" + responseString);
        }
        await _httpClient.PostAsync(_httpClient.BaseAddress, content);
    }

    public async Task WriteOutputFiles(FileSystemInfo jsonFile)
    {
        StringBuilder isoCwPolicyMpSb = new(), isoTxPolicyMpSb = new();
        foreach (var msg in _policyQueue)
            switch (msg.Name)
            {
                case "ISO_CW_PolicyMP":
                    isoCwPolicyMpSb.AppendLine(msg.Value); break;
                case "ISO_TX_PolicyMP":
                    isoTxPolicyMpSb.AppendLine(msg.Value); break;
            }

        var batchCountStr = Variables.BatchCount.ToString("D4");

        if (isoCwPolicyMpSb.Length > 0)
            await File.WriteAllTextAsync(Path.Combine(_appSettings.CsvSplitFilesFolder!,
                    jsonFile.Name.Replace(".json", " ") + $"ISO_CW_PolicyMP{batchCountStr}.txt"),
                isoCwPolicyMpSb.ToString());

        if (isoTxPolicyMpSb.Length > 0)
            await File.WriteAllTextAsync(Path.Combine(_appSettings.CsvSplitFilesFolder!,
                    jsonFile.Name.Replace(".json", " ") + $"ISO_TX_PolicyMP{batchCountStr}.txt"),
                isoTxPolicyMpSb.ToString());
    }

    private async Task SaveRequestJsonToFile(object request, string suffix)
    {
        var fileName = _appSettings.RequestsFolder + $"/{Variables.BatchCount}_{Variables.RunCount}{suffix}";
        await File.WriteAllTextAsync(fileName, JsonConvert.SerializeObject(request));
    }

    private async Task SaveRequestAndResponseFiles(object applyRulesRequest, ExecutionResponse executionResponse)
    {
        await SaveRequestJsonToFile(applyRulesRequest, "_request.json");
        await SaveRequestJsonToFile(executionResponse, "_response.json");

        var content = new StringContent(JsonConvert.SerializeObject(applyRulesRequest), Encoding.UTF8,"application/json");
        content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        var httpResponse = await _httpClient.PostAsync(_httpClient.BaseAddress, content);
        var responseString = await httpResponse.Content.ReadAsStringAsync();
        await SaveRequestJsonToFile(responseString, "_log_response.json");
    }

    private ApplyRulesRequest CreateApplyRulesRequest(string entityState, bool logging = false)
    {
        return new ApplyRulesRequest
        {
            RuleApp = new RuleApp
            {
                RepositoryRuleAppRevisionSpec = new RepositoryRuleAppRevisionSpec
                {
                    RuleApplicationName = _appSettings.RuleApplicationName
                }
            },
            EntityName = _appSettings.EntityName!,
            EntityState = entityState,
            RuleEngineServiceOutputTypes = logging ? new RuleEngineServiceOutputTypes { RuleExecutionLog = true } : null
        };
    }

    private void ProcessExecutionResponse(ExecutionResponse executionResponse)
    {
        var entityState = JsonConvert.DeserializeObject<IsoFinalEntityState>(executionResponse.EntityState!);
        if (entityState!.RuleOutput is null)
            return;
        foreach (var ruleOutput in entityState.RuleOutput)
        {
            if (!string.IsNullOrEmpty(ruleOutput.ISO_CW_PolicyMP))
                _policyQueue.Enqueue(
                    new PolicyInfo { Name = "ISO_CW_PolicyMP", Value = ruleOutput.ISO_CW_PolicyMP });
            if (!string.IsNullOrEmpty(ruleOutput.ISO_TX_PolicyMP))
                _policyQueue.Enqueue(
                    new PolicyInfo { Name = "ISO_TX_PolicyMP", Value = ruleOutput.ISO_TX_PolicyMP });
        }
    }

    private void LogAndReportFailure(HttpStatusCode statusCode, IReadOnlyList<Iso> isoData, bool runtimeErrors)
    {
        _logger.LogError(
            "Apply rules request failed with status code {StatusCode} for batch {BatchCount} run {RunCount}",
            statusCode, Variables.BatchCount, Variables.RunCount);
        _report.LogToReport(isoData, PolicyStatus.Failed, runtimeErrors);
    }
}