﻿using QBERuleRunner.Models;
using System.Text;
using Microsoft.Extensions.Logging;

namespace QBERuleRunner;
public interface IReport
{
    void LogToReport(IReadOnlyList<Iso> isoData, PolicyStatus status, bool runtimeErrors);
    void RunReport(string elapsedTimeString);
}
public class Report : IReport
{
    private readonly AppSettings _appSettings;
    private readonly List<RuleReportRecords> _ruleReportRecords;
    private readonly ILogger<Report> _logger;
    public Report(ILogger<Report> logger) { 
        _appSettings = Program.AppSettings;  
        _ruleReportRecords = new List<RuleReportRecords>();
        _logger = logger;
    }
    
    public void LogToReport(IReadOnlyList<Iso> isoData, PolicyStatus status, bool runtimeErrors)
    {
        var recordCount = isoData.Count;
        List<RuleReportRecords> ruleReportRecords = new();
        for (var i = 0; i < recordCount; i++)
        {
            ruleReportRecords.Add(new RuleReportRecords
            {
                PolicyNumber = isoData[i].PolicyNumber!,
                Status = status,
                BatchCount = Variables.BatchCount.ToString(),
                RunCount = Variables.RunCount.ToString(),
                RuntimeErrors = runtimeErrors,
            });
        }
        _ruleReportRecords.AddRange(ruleReportRecords);
    }

    public void RunReport(string elapsedTimeString)
    {
        RuleReportTotal ruleReportTotal = new()
        {
            FileCount = Variables.FileCount.ToString(),
            TotalRecords = Variables.PolicyCount.ToString(),
            ObjectsPerFileForSplit = _appSettings.ObjectsPerFileForSplit!,
            InRuleMessageSize = _appSettings.InRuleMessageSize.ToString(),
            MaxRequestsAtOneTime = _appSettings.MaxRequestsAtOneTime.ToString(),
            CompletedTime = elapsedTimeString
        };
        var runtimeErrors = _ruleReportRecords.Any(record => record.RuntimeErrors);

        var reportBuilder = new StringBuilder();
        reportBuilder.AppendLine("QBE RuleRunner Report");
        reportBuilder.AppendLine($"Duration: {ruleReportTotal.CompletedTime}");
        reportBuilder.AppendLine($"Total number of processed ISO records: {ruleReportTotal.TotalRecords}");
        reportBuilder.AppendLine($"Total number of processed files/batches: {ruleReportTotal.FileCount}");
        reportBuilder.AppendLine($"Message size: {ruleReportTotal.InRuleMessageSize}");
        reportBuilder.AppendLine($"Max requests at one time: {ruleReportTotal.MaxRequestsAtOneTime}");
        reportBuilder.AppendLine($"Has run time errors: {runtimeErrors}");

        if (_ruleReportRecords.Any())
        {
            reportBuilder.AppendLine("Rule Report Records:");
            reportBuilder.AppendLine(GetReportTable(_ruleReportRecords));
        }

        var fileName = _appSettings.ReportFolder + $"Reports{DateTime.Now:yyyyMMddHHmmssfff}.txt";
        if (reportBuilder.Length > 0)
            File.WriteAllText(fileName, reportBuilder.ToString());
        _logger.LogInformation("Generated report: {fileName}", fileName);
    }

    private string GetReportTable(List<RuleReportRecords> ruleReportRecords)
    {
        var tableBuilder = new StringBuilder();
        tableBuilder.AppendLine("+----------------+-----------+----------------+------------+");
        tableBuilder.AppendLine("| Policy Number  |   Status  |  Batch Number  | Run Number |");
        tableBuilder.AppendLine("+----------------+-----------+----------------+------------+");

        foreach (var record in ruleReportRecords)
        {
            tableBuilder.AppendLine($"| {record.PolicyNumber,-14} | {record.Status,-6} | {record.BatchCount,-13} | {record.RunCount,-10} |");
        }

        tableBuilder.AppendLine("+----------------+-----------+----------------+------------+");
        return tableBuilder.ToString();
    }

}