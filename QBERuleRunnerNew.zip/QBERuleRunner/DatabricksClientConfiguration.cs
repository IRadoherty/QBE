﻿namespace QBERuleRunner
{
    internal class DatabricksClientConfiguration
    {
        public string Token { get; set; }
        public string Host { get; set; }
    }
}