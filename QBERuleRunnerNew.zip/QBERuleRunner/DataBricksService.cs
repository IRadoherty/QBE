﻿using Microsoft.Data.SqlClient;

namespace QBERuleRunner;

internal class DataBricksService
{
    public void Connect()
    {

        // Set up the client configuration
        string connectionString = "Driver={Databricks};Host=<instance-hostname>;Port=10000;UID=<username>;PWD=<password>;HTTPPath=<instance-http-path>;AuthMech=3";

        // Create a new SqlConnection
        using SqlConnection conn = new SqlConnection(connectionString);
        try
        {
            // Open the connection
            conn.Open();

            // Execute a simple query
            using SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM <your-table-name>", conn);
            int count = (int)cmd.ExecuteScalar();
            Console.WriteLine($"Count: {count}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }


    }
}


