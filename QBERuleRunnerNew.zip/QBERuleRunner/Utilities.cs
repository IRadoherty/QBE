﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using QBERuleRunner.Models;

namespace QBERuleRunner;

public interface IUtilities
{
    void CombineCsvFiles();
    void DeleteSplitFiles();
    void SplitInitialFile();
    void RemoveExtraFields();
    Directories GetJsonSplitDirectory();
}

public class Directories
{
    public FileInfo[] CsvFiles = null!;
    public FileInfo[] JsonFiles = null!;

    public async IAsyncEnumerable<FileSystemInfo> GetFilesAsync()
    {
        var allFiles = CsvFiles.Concat(JsonFiles);
        foreach (var file in allFiles)
        {
            yield return file;
            await Task.Yield();
        }
    }
}

public class Utilities : IUtilities
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<Utilities> _logger;

    public Utilities(ILogger<Utilities> logger) => (_logger, _appSettings) = (logger, Program.AppSettings);

    public void CombineCsvFiles()
    {
        var csvFiles = Directory.GetFiles(_appSettings.CsvSplitFilesFolder!, "*.txt");
        CombineFilesAndWriteContent(csvFiles, "ISO_CW_PolicyMP");
        CombineFilesAndWriteContent(csvFiles, "ISO_TX_PolicyMP");
    }
    private void CombineFilesAndWriteContent(IEnumerable<string> csvFiles, string policyType)
    {
        using StreamWriter outputWriter = new(Path.Combine(_appSettings.CsvOutputFolder!, $"{policyType}.csv"));
        foreach (var file in csvFiles.Where(file => Path.GetFileNameWithoutExtension(file).Contains(policyType)).ToList())
        {
            using StreamReader inputReader = new (file);
            while (!inputReader.EndOfStream)
            {
                outputWriter.WriteLine(inputReader.ReadLine());
            }
        }
    }

    public void SplitInitialFile()
    {
        RemoveOuterBrackets();
        SplitJsonFiles();
    }

    private void RemoveOuterBrackets()
    {
        foreach (var jsonFile in GetJsonInputDirectory().JsonFiles)
        {
            var tempFileName = Path.GetTempFileName();
            using (StreamReader reader = new(jsonFile.FullName))
            using (StreamWriter writer = new(tempFileName))
            {
                while ((char)reader.Peek() != '[')
                {
                    reader.Read();
                }
                char[] buffer = new char[4096];
                int bytesRead;
                while ((bytesRead = reader.Read(buffer, 0, buffer.Length)) > 0)
                {
                    int bytesToWrite = bytesRead;
                    if (reader.Peek() == -1)
                        bytesToWrite--;

                    writer.Write(buffer, 0, bytesToWrite);
                }
            }
            File.Replace(tempFileName, jsonFile.FullName, null);
        }
    }

    private void SplitJsonFiles()
    {
        int objectsPerFile = int.Parse(_appSettings.ObjectsPerFileForSplit!);
        int fileCounter = 0, objectCounter = 0;
        foreach (var jsonFile in GetJsonInputDirectory().JsonFiles)
        {
            using StreamReader sr = new(jsonFile.FullName);
            using JsonTextReader reader = new(sr);

            StreamWriter? sw = null;
            JsonTextWriter? writer = null;
            while (reader.Read())
            {
                if (reader.TokenType != JsonToken.StartObject)
                    continue;
                if (objectCounter % objectsPerFile == 0)
                {
                    if (writer is not null)
                    {
                        writer.WriteEndArray();
                        writer.Close();
                        sw.Dispose();
                    }
                    fileCounter++;
                    string formattedNumber = fileCounter.ToString("D4");
                    sw = new StreamWriter(Path.Combine(_appSettings.JsonSplitFilesFolder!, jsonFile.Name.Replace(".json", "") + $"_splitFile_{formattedNumber}.json"));
                    writer = new JsonTextWriter(sw) { Formatting = Formatting.None };
                    writer.WriteStartArray();
                    _logger.LogInformation("Wrote JSON file: {Name}", $"{jsonFile.Name}_splitFile_{formattedNumber}.json");
                }
                objectCounter++;
                writer.WriteToken(reader);
            }
            if (writer is null)
                continue;
            writer.WriteEndArray();
            writer.Close();
            sw.Dispose();
        }
    }

    public void DeleteSplitFiles()
    {
        string[] folders = { _appSettings.JsonSplitFilesFolder!, _appSettings.CsvSplitFilesFolder!, _appSettings.CsvOutputFolder! };

        foreach (var folder in folders)
        foreach (var file in Directory.GetFiles(folder))
        {
            File.Delete(file);
            _logger.LogInformation("Deleted file: {File}", file);
        }
    }

    private Directories GetJsonInputDirectory() => GetDirectory(_appSettings.JsonInputFolder!);
    public Directories GetJsonSplitDirectory() => GetDirectory(_appSettings.JsonSplitFilesFolder!);
    public Directories GetCsvSplitDirectory() => GetDirectory(_appSettings.CsvSplitFilesFolder!);

    private static Directories GetDirectory(string folderPath)
    {
        var directories = new Directories();
        var jsonDirectory = new DirectoryInfo(folderPath);
        directories.JsonFiles = jsonDirectory.GetFiles("*.json*");
        directories.CsvFiles = jsonDirectory.GetFiles("*.csv*");
        return directories;
    }
    
    
    public async void RemoveExtraFields()
    {
        _logger.LogInformation("Removing unneeded fields..");
        await foreach (var jsonFile in GetJsonSplitDirectory().GetFilesAsync().ConfigureAwait(false))
        {
            var jsonString = await File.ReadAllTextAsync(jsonFile.FullName);
            var jsonObject = JsonConvert.DeserializeObject<List<Iso>>(jsonString);
            var fieldsToRemove = new List<string> { "PolicyLimitAmount_ADVLIAO",
"PolicyLimitAmount_ADVLIAP",
"PolicyLimitAmount_AGLGEN",
"PolicyLimitAmount_AGLPAI",
"PolicyLimitAmount_AGLPCO",
"PolicyLimitAmount_AggregateCap",
"PolicyLimitAmount_AggregateLiabilityCoverage",
"PolicyLimitAmount_Aggregate_Liab_Limit",
"PolicyLimitAmount_AttachmentAggregateLimit",
"PolicyLimitAmount_BodilyInjuryByAccidentLimit_AdmiraltyLawandFELA",
"PolicyLimitAmount_BodilyInjuryByAccident_EachAccidentLimit",
"PolicyLimitAmount_BodilyInjuryByDiseaseLimit_AdmiraltyLawandFELA",
"PolicyLimitAmount_BodilyInjuryByDisease_EachEmployeeLimit",
"PolicyLimitAmount_BodilyInjuryByDisease_PolicyLimit",
"PolicyLimitAmount_Bodily_Injury_Each_Occurrence",
"PolicyLimitAmount_Bodily_Injury_Each_Person",
"PolicyLimitAmount_Business_Liab_Limit",
"PolicyLimitAmount_CContingentLimit",
"PolicyLimitAmount_CEachLossLimitOveride",
"PolicyLimitAmount_CHEMBIEO",
"PolicyLimitAmount_CHEMBIEP",
"PolicyLimitAmount_CHEMPDAG",
"PolicyLimitAmount_CHEMPDEO",
"PolicyLimitAmount_CHEMSLAG",
"PolicyLimitAmount_CHEMSLEO",
"PolicyLimitAmount_CONTLIAO",
"PolicyLimitAmount_CONTLIAV",
"PolicyLimitAmount_CSL_Each_Occurrence",
"PolicyLimitAmount_DamagePremRent",
"PolicyLimitAmount_EMPLIA",
"PolicyLimitAmount_EMPLOYERS_LIAB_Limit",
"PolicyLimitAmount_EachAirLimitOveride",
"PolicyLimitAmount_EachAircarft",
"PolicyLimitAmount_EachLocationAggregate",
"PolicyLimitAmount_EachLoss",
"PolicyLimitAmount_EachOccurance",
"PolicyLimitAmount_EachOccurrence",
"PolicyLimitAmount_EachOccurrenceDisplay",
"PolicyLimitAmount_GeneralAggregate",
"PolicyLimitAmount_HKAOA",
"PolicyLimitAmount_HKAOO",
"PolicyLimitAmount_HSTLIQO",
"PolicyLimitAmount_INDCONTO",
"PolicyLimitAmount_INDCONTV",
"PolicyLimitAmount_LIABIP",
"PolicyLimitAmount_LIACSL",
"PolicyLimitAmount_LIAPPAS",
"PolicyLimitAmount_LIAPPER",
"PolicyLimitAmount_LayerAggregateLimit",
"PolicyLimitAmount_LayerOccurrenceLimit",
"PolicyLimitAmount_MEDOCC",
"PolicyLimitAmount_MEDPER",
"PolicyLimitAmount_MedicalExpenses",
"PolicyLimitAmount_Medical_Expense_Limit",
"PolicyLimitAmount_Medical_Expenses_Each_Occurrence",
"PolicyLimitAmount_Medical_Expenses_Per_Person",
"PolicyLimitAmount_NOCHAPEO",
"PolicyLimitAmount_NOCHSLAG",
"PolicyLimitAmount_NOCHSLEO",
"PolicyLimitAmount_ONPRMP",
"PolicyLimitAmount_OverrideAttachmentAggregateLimit",
"PolicyLimitAmount_OverrideAttachmentLimit",
"PolicyLimitAmount_OverrideQBEAggregateLimit",
"PolicyLimitAmount_OverrideTotalProgramLimit",
"PolicyLimitAmount_PILIAO",
"PolicyLimitAmount_PRDCSL",
"PolicyLimitAmount_PRMCSL",
"PolicyLimitAmount_PRMMEDE",
"PolicyLimitAmount_PRMRTY",
"PolicyLimitAmount_Passenger_Liability_Each_Occurrence",
"PolicyLimitAmount_Passenger_Liability_Each_Person",
"PolicyLimitAmount_Passenger_Liability_Limit",
"PolicyLimitAmount_PersAdverInjAggLimit",
"PolicyLimitAmount_PersonalandAdvertisingInjury",
"PolicyLimitAmount_ProdOpsAggLimit",
"PolicyLimitAmount_ProductandCompletedOperationsAggregateLimit",
"PolicyLimitAmount_ProfessionalAggregrate",
"PolicyLimitAmount_Umbrella",
"PolicyLimitAmount_UmbrellaDisplay",
"CoverageDeductibleAmount_AN",
"CoverageDeductibleAmount_ArtificiallyGeneratedEnergy",
"CoverageDeductibleAmount_BAGEAEV",
"CoverageDeductibleAmount_BDEDCT",
"CoverageDeductibleAmount_BENCO",
"CoverageDeductibleAmount_BIPD",
"CoverageDeductibleAmount_BLDDED",
"CoverageDeductibleAmount_BLDDEDA",
"CoverageDeductibleAmount_BLDDEDB",
"CoverageDeductibleAmount_BLDDEDC",
"CoverageDeductibleAmount_BLDDEDD",
"CoverageDeductibleAmount_BLDDEDE",
"CoverageDeductibleAmount_BLDGORD",
"CoverageDeductibleAmount_BOEQ",
"CoverageDeductibleAmount_BOP_EPMT_Deductible",
"CoverageDeductibleAmount_BOP_EQBG_Deductible",
"CoverageDeductibleAmount_BOP_EQBI_Deductible",
"CoverageDeductibleAmount_BOP_EQPP_Deductible",
"CoverageDeductibleAmount_BOP_SBBB_Deductible",
"CoverageDeductibleAmount_BOP_SCNB_Deductible",
"CoverageDeductibleAmount_BOP_SCWB_Deductible",
"CoverageDeductibleAmount_BT_Deductible",
"CoverageDeductibleAmount_BUSDED",
"CoverageDeductibleAmount_BlanketDeductible",
"CoverageDeductibleAmount_Boat_Deductible",
"CoverageDeductibleAmount_BusinessIncomeTimeDeductible",
"CoverageDeductibleAmount_CARGODED",
"CoverageDeductibleAmount_CF_Act_Deductible",
"CoverageDeductibleAmount_CF_Deductible",
"CoverageDeductibleAmount_CF_Deductible_Per",
"CoverageDeductibleAmount_CF_NFIP_Deductible",
"CoverageDeductibleAmount_CHCMPD",
"CoverageDeductibleAmount_CHCOLD",
"CoverageDeductibleAmount_CL",
"CoverageDeductibleAmount_CLNTPRDeductible",
"CoverageDeductibleAmount_CMPDED",
"CoverageDeductibleAmount_CMPFTFDeductible",
"CoverageDeductibleAmount_COLDED",
"CoverageDeductibleAmount_COMARTDeductible",
"CoverageDeductibleAmount_COVDED",
"CoverageDeductibleAmount_CY",
"CoverageDeductibleAmount_Coinsurance",
"CoverageDeductibleAmount_Combined_AllCoveragesDeductible",
"CoverageDeductibleAmount_ComputerAttack_FirstPartyCoverageDeductible",
"CoverageDeductibleAmount_ComputerAttackDeductible",
"CoverageDeductibleAmount_Contractor_Deductible_Amount",
"CoverageDeductibleAmount_Contractor_Liability_Deductible",
"CoverageDeductibleAmount_DDACEL",
"CoverageDeductibleAmount_DDALEO",
"CoverageDeductibleAmount_DDCLEL",
"CoverageDeductibleAmount_DDEMEL",
"CoverageDeductibleAmount_DDEMWC",
"CoverageDeductibleAmount_DDRTAD",
"CoverageDeductibleAmount_DEDACC",
"CoverageDeductibleAmount_DEDAOB",
"CoverageDeductibleAmount_DEDAOC",
"CoverageDeductibleAmount_DEDG1B",
"CoverageDeductibleAmount_DEDG1C",
"CoverageDeductibleAmount_DEDG2B",
"CoverageDeductibleAmount_DEDG2C",
"CoverageDeductibleAmount_DEDTBL",
"CoverageDeductibleAmount_DEDUCTIBLE_AMOUNT",
"CoverageDeductibleAmount_DEDUCTIBLE_TYPE",
"CoverageDeductibleAmount_Deductible",
"CoverageDeductibleAmount_Deductible_NetworkSecurityLiability_",
"CoverageDeductibleAmount_DeductibleAmount",
"CoverageDeductibleAmount_DeductibleBIFactor",
"CoverageDeductibleAmount_DeductibleBIandPDFactor",
"CoverageDeductibleAmount_DeductibleFactor",
"CoverageDeductibleAmount_DeductibleMethod",
"CoverageDeductibleAmount_DeductiblePDFactor",
"CoverageDeductibleAmount_DeductiblePercentage",
"CoverageDeductibleAmount_Deductible_Code",
"CoverageDeductibleAmount_DefenseandLiabilityDeductible",
"CoverageDeductibleAmount_DirectCoveragesDeductible",
"CoverageDeductibleAmount_EDEDCT",
"CoverageDeductibleAmount_EDPDeductible",
"CoverageDeductibleAmount_EMPDeductible",
"CoverageDeductibleAmount_EQUDLRDeductible",
"CoverageDeductibleAmount_EQ_Deductible",
"CoverageDeductibleAmount_EXPDED",
"CoverageDeductibleAmount_EXTCEDeductible",
"CoverageDeductibleAmount_EachEmployeeDeductible",
"CoverageDeductibleAmount_EarthquakeDeductiblePercentage",
"CoverageDeductibleAmount_EarthquakeFlatDeductible",
"CoverageDeductibleAmount_FLEXBIZ_Deductible",
"CoverageDeductibleAmount_FLEXBIZ_WIND_Hail_Deductible",
"CoverageDeductibleAmount_FORGDeductible",
"CoverageDeductibleAmount_FT_Deductible",
"CoverageDeductibleAmount_Fire_Deductible",
"CoverageDeductibleAmount_Fixed",
"CoverageDeductibleAmount_FloodDeductible",
"CoverageDeductibleAmount_GARAGEKDED",
"CoverageDeductibleAmount_GLASS_DED",
"CoverageDeductibleAmount_GL_BI_Deductible",
"CoverageDeductibleAmount_GNIMDED",
"CoverageDeductibleAmount_GPRDD",
"CoverageDeductibleAmount_GS_DEDUCTIBLE",
"CoverageDeductibleAmount_HANGARKAD",
"CoverageDeductibleAmount_HANGARKOD",
"CoverageDeductibleAmount_HD_In_Motion",
"CoverageDeductibleAmount_HD_Not_In_Motion",
"CoverageDeductibleAmount_HKFWDED",
"CoverageDeductibleAmount_HKRWDED",
"CoverageDeductibleAmount_HL_PD_Deductible",
"CoverageDeductibleAmount_Homeowner_wind_Hail_Ded_Amount",
"CoverageDeductibleAmount_Homeowners_Deductible",
"CoverageDeductibleAmount_Homeowners_Teft_250_Deductible",
"CoverageDeductibleAmount_Homeowners_Windstorm_Ded",
"CoverageDeductibleAmount_Homeowners_Windstorm_Deductible_Amt",
"CoverageDeductibleAmount_INMDED",
"CoverageDeductibleAmount_IncreasedLimitLessDeductibleFactor",
"CoverageDeductibleAmount_LiabilityDeductible",
"CoverageDeductibleAmount_MDEDCT",
"CoverageDeductibleAmount_MOCPCDeductible",
"CoverageDeductibleAmount_MRCDeductible",
"CoverageDeductibleAmount_MTDED",
"CoverageDeductibleAmount_MedicalBenefitsDeductible",
"CoverageDeductibleAmount_MiniComputerDeductible",
"CoverageDeductibleAmount_NOCHPDIM",
"CoverageDeductibleAmount_NOCHPDNIM",
"CoverageDeductibleAmount_NODED",
"CoverageDeductibleAmount_NetworkSecurity_ThirdPartyCoverageDeductible",
"CoverageDeductibleAmount_OTHSTR",
"CoverageDeductibleAmount_OUTPRMDeductible",
"CoverageDeductibleAmount_OtherCausesofLoss",
"CoverageDeductibleAmount_OtherthanArtificiallyGeneratedEnergy",
"CoverageDeductibleAmount_PDEDCT",
"CoverageDeductibleAmount_PERDED",
"CoverageDeductibleAmount_PIPDeductible",
"CoverageDeductibleAmount_PerClaimDeductible",
"CoverageDeductibleAmount_PerCommonCauseDeductible",
"CoverageDeductibleAmount_PolicyAggregateDeductibleAmount",
"CoverageDeductibleAmount_PortableComputers_Deductible",
"CoverageDeductibleAmount_Premises_Operations",
"CoverageDeductibleAmount_Premises_OperationsDeductible",
"CoverageDeductibleAmount_Premises_OpsBIAndPDCombinedDeductible",
"CoverageDeductibleAmount_Premises_OpsBodilyInjuryDeductibleCode",
"CoverageDeductibleAmount_Premises_OpsPropertyDamageDeductiblesCode",
"CoverageDeductibleAmount_ProductsBIAndPDCombinedDeductible",
"CoverageDeductibleAmount_ProductsBodilyInjuryDeductibleCode",
"CoverageDeductibleAmount_ProductsDeductible",
"CoverageDeductibleAmount_ProductsPropertyDamageDeductibleCode",
"CoverageDeductibleAmount_Products_CompletedOps",
"CoverageDeductibleAmount_PropertyDamageDeductible",
"CoverageDeductibleAmount_PropertyDamageDeductibleCode",
"CoverageDeductibleAmount_PropertyDeductible",
"CoverageDeductibleAmount_RSBMSDeductible",
"CoverageDeductibleAmount_RSBOPDeductible",
"CoverageDeductibleAmount_RecallDeductible",
"CoverageDeductibleAmount_ResponseExpensesDeductible",
"CoverageDeductibleAmount_SDEDCT",
"CoverageDeductibleAmount_SectionIDeductible",
"CoverageDeductibleAmount_SpecialFormTheft",
"CoverageDeductibleAmount_THFDED",
"CoverageDeductibleAmount_THFTMSDeductible",
"CoverageDeductibleAmount_THFTOPDeductible",
"CoverageDeductibleAmount_VALPAPDeductible",
"CoverageDeductibleAmount_WINDHAILDeductible",
"CoverageDeductibleAmount_WNDDCT",
"CoverageDeductibleAmount_W_H_DED",
"CoverageDeductibleAmount_WaterDamageDeductible",
"CoverageDeductibleAmount_WindstormorHailDeductible",
"CoverageDeductibleAmount_WorkersComp_Deductible_Amt1",
"CoverageDeductibleAmount_WorkersComp_Deductible_Amt2",
"CoverageLimitAmount_Added_Limit",
"CoverageLimitAmount_AggregateLimitEbl",
"CoverageLimitAmount_AmendmentLimitProv",
"CoverageLimitAmount_Basic_Limit",
"CoverageLimitAmount_Bodily_Injury_Occurance_Liability_Limit",
"CoverageLimitAmount_Bodily_Injury_Per_Liability_Limit",
"CoverageLimitAmount_CSL_Liability_Limit",
"CoverageLimitAmount_CombinedSingleLimit",
"CoverageLimitAmount_Combined_Single_Limit",
"CoverageLimitAmount_Combined_Single_Limit_Display",
"CoverageLimitAmount_Completed_Product_Operations",
"CoverageLimitAmount_DamagePrmsRntdLimit",
"CoverageLimitAmount_DispAggregateLimit",
"CoverageLimitAmount_DispAggregateLimitEbl",
"CoverageLimitAmount_DispEachCommCauLimit",
"CoverageLimitAmount_DispEachEmpLimitEbl",
"CoverageLimitAmount_DispEachOccLimitCsl",
"CoverageLimitAmount_DispGenAggLimitCsl",
"CoverageLimitAmount_DispGenAggLimitPwc",
"CoverageLimitAmount_DispOccLimitPwc",
"CoverageLimitAmount_DispPrdcoAgglimitCsl",
"CoverageLimitAmount_DmgPrmsRntdLmtAmt",
"CoverageLimitAmount_EachAccidentLimit",
"CoverageLimitAmount_EachCommCauLimit",
"CoverageLimitAmount_EachEmpLimitEbl",
"CoverageLimitAmount_EachEmployeeLimit",
"CoverageLimitAmount_EachOccLimitCsl",
"CoverageLimitAmount_Each_Additional_Limit",
"CoverageLimitAmount_Each_Occurrence_Limit",
"CoverageLimitAmount_GeneralAggLimitCsl",
"CoverageLimitAmount_GeneralAggLimitPwc",
"CoverageLimitAmount_IncLimitFactor",
"CoverageLimitAmount_IncLmtBiFactor",
"CoverageLimitAmount_IncLmtCslFactor",
"CoverageLimitAmount_IncLmtPdFactor",
"CoverageLimitAmount_IncreasedLimitsMinimumPremium",
"CoverageLimitAmount_Increased_Limit",
"CoverageLimitAmount_Limit",
"CoverageLimitAmount_LimitIdentifierCode",
"CoverageLimitAmount_LimitPerAccident",
"CoverageLimitAmount_Limit_Code",
"CoverageLimitAmount_Limit_Code_2",
"CoverageLimitAmount_MI_Medical_Benefit_Limit",
"CoverageLimitAmount_Maximum_Limit",
"CoverageLimitAmount_MedExpenseIncLmtFact",
"CoverageLimitAmount_MedExpenseLimit",
"CoverageLimitAmount_MedExpenseLmtAmt",
"CoverageLimitAmount_Medical_Expense_Limit",
"CoverageLimitAmount_PerOcccurrence",
"CoverageLimitAmount_PerPerson",
"CoverageLimitAmount_Per_Aircraft_Limit",
"CoverageLimitAmount_Per_Occurrence_Limit",
"CoverageLimitAmount_PersonalAdInjuryLimit",
"CoverageLimitAmount_PolicyLimit",
"CoverageLimitAmount_PolicyLimitCode",
"CoverageLimitAmount_PrdCompopAgglimitCsl",
"CoverageLimitAmount_Print_Limit",
"CoverageLimitAmount_Prod_Rate_Each_Occurance",
"CoverageLimitAmount_RepatriationCoverage_LimitPerEmployee",
"CoverageLimitAmount_SMinPreIncLmtCslFact",
"CoverageLimitAmount_SpMinPreIncLmtPdFact",
"CoverageLimitAmount_SpMinPreIncLmtBiFact",
"CoverageLimitAmount_Tort_Limit_Code" };
            foreach (var field in fieldsToRemove)
            {
                GetType().GetProperty(field)?.SetValue(this, null);
            }
            await File.WriteAllTextAsync(jsonFile.FullName, JsonConvert.SerializeObject(jsonObject));
        }
    }
}