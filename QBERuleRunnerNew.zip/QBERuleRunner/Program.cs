﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using QBERuleRunner.Models;
using QBERuleRunner.Services;
using Serilog;
using Serilog.Events;

namespace QBERuleRunner;

internal static class Program
{
    public static AppSettings AppSettings { get; private set; } = null!;

    private static async Task Main()
    {
        try
        {
            var config = LoadConfiguration();

            AppSettings = config.GetRequiredSection("AppSettings").Get<AppSettings>();

            ConfigureLogging(config);

            using var host = CreateHostBuilder().Build();

            var startTime = DateTime.UtcNow;
            Log.Logger.Information("{RuleRunner} Has Started - {startTime}", nameof(RuleRunner), startTime);

            await host.StartAsync();
            var ruleRunner = host.Services.GetRequiredService<RuleRunner>();
            await ruleRunner.StartRuleRunner();

            await host.WaitForShutdownAsync();
            Log.Logger.Information("{RuleRunner} Has Shutdown: {DateTime} Up time: {elapsedTime} minutes.",
                nameof(RuleRunner), DateTime.UtcNow, Math.Round((DateTime.UtcNow - startTime).TotalMinutes, 2));
        }
        catch (Exception e)
        {
            Log.Logger.Error(e, "{RuleRunner} encountered an error: {Message}", nameof(RuleRunner), e.Message);
        }
    }

    private static IConfiguration LoadConfiguration()
    {
        return new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .AddEnvironmentVariables()
            .Build();
    }

    private static void ConfigureLogging(IConfiguration config)
    {
        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(config)
            .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
            .CreateLogger();
    }

    private static IHostBuilder CreateHostBuilder()
    {
        return Host.CreateDefaultBuilder()
            .ConfigureServices(services =>
            {
                services.AddSingleton<RuleRunner>();
                services.AddSingleton<IUtilities, Utilities>();
                services.AddSingleton<IReport, Report>();
                services.AddSingleton<IExecutionService, ExecutionService>();
                services.AddSingleton<IFileProcessing, FileProcessing>();
                ConfigureHttpClients(services);
            })
            .UseSerilog();
    }

    private static void ConfigureHttpClients(IServiceCollection services)
    {
        services.AddHttpClient("ApplyRules", (client) => ConfigureHttpClient(client, "ApplyRules"));
        services.AddHttpClient("ExecuteRuleSet", (client) => ConfigureHttpClient(client, "ExecuteRuleSet"));
        services.AddHttpClient("ExecuteDecision", (client) => ConfigureHttpClient(client, "ExecuteDecision"));
    }

    private static void ConfigureHttpClient(HttpClient client, string clientName)
    {
        client.BaseAddress = new Uri(new Uri(AppSettings.ExecutionServiceUrl!), $"HttpService.svc/{clientName}");
        client.DefaultRequestHeaders.Add("Accept", "application/json");
        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", AppSettings.ApiKey);
        client.Timeout = TimeSpan.FromSeconds(120);
    }

}
