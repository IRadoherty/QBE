﻿using System.Diagnostics;
using Microsoft.Extensions.Logging;
using QBERuleRunner.Models;

namespace QBERuleRunner;
public class RuleRunner
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<RuleRunner> _logger;
    private readonly IUtilities _utilities;
    private readonly IFileProcessing _fileProcessing;
    private readonly IReport _report;
    
    public RuleRunner(ILogger<RuleRunner> logger, IUtilities utilities, IReport report, IFileProcessing fileProcessing)
    {
        _appSettings = Program.AppSettings;
        _logger = logger;
        _utilities = utilities;
        _report = report;
        _fileProcessing = fileProcessing;
    }

    public async Task StartRuleRunner()
    {
        try
        {
            DefineVariables();
            _utilities.DeleteSplitFiles();
            _utilities.SplitInitialFile();
            _utilities.RemoveExtraFields();
            var stopwatch = Stopwatch.StartNew();
            await _fileProcessing.ProcessFiles();
            _utilities.CombineCsvFiles();
            stopwatch.Stop();
            _logger.LogInformation("{RuleRunner} completed in {Elapsed}", nameof(RuleRunner), stopwatch.Elapsed);

            if (!_appSettings.RunReport)
                return;

            var elapsedTime = stopwatch.Elapsed;
            var elapsedTimeString =
                $"{elapsedTime.Hours:00}:{elapsedTime.Minutes:00}:{elapsedTime.Seconds:00}.{elapsedTime.Milliseconds:000}";

            _report.RunReport(elapsedTimeString);
        }
        catch (Exception e)
        {
            _logger.LogError(e,"{RuleRunner} encountered an error: {Message}", nameof(RuleRunner), e.Message);
        }
    }

    private static void DefineVariables()
    {
        Variables.BatchCount = 0;
        Variables.PolicyCount = 0;
        Variables.BatchCount = 0;
        Variables.RuntimeErrors = false;
        Variables.FileCount = 0;
        //Variables.FileCount = 915;
        
    }
}