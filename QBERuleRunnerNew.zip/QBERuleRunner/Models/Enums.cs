﻿namespace QBERuleRunner.Models;

public enum PolicyStatus
{
    Completed,
    Failed
}
