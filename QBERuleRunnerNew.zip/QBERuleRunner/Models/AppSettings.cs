﻿namespace QBERuleRunner.Models;
public class AppSettings
{
    public string? JsonInputFolder { get; set; }
    public string? JsonOutputFolder { get; set; }
    public string? JsonSplitFilesFolder { get; set; }
    public string? JsonCompleteFolder { get; set; }
    public string? CsvOutputFolder { get; set; }
    public string? CsvSplitFilesFolder { get; set; }
    public string? RequestsFolder { get; set; }
    public int MaxRetries { get; set; }
    public int InRuleMessageSize { get; set; }
    public int MaxRequestsAtOneTime { get; set; }
    public string? RuleApplicationName { get; set; }
    public string? ExecutionServiceUrl { get; set; }
    public string? ApiKey { get; set; }
    public string? EntityName { get; set; }
    public string? Label { get; set; }
    public string? ObjectsPerFileForSplit { get; set; }
    public string? ReportFolder { get; set; }
    public bool RunReport { get; set; }
}
