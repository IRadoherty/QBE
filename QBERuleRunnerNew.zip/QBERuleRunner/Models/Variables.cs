﻿namespace QBERuleRunner.Models;

public static class Variables
{
    public static int PolicyCount { get; set; }
    public static int BatchCount { get; set; }
    public static int RunCount { get; set; }
    public static int FileCount { get; set; }
    public static bool RuntimeErrors { get; set; }
}
