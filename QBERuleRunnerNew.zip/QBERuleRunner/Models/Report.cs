﻿namespace QBERuleRunner.Models;

public class RuleReportRecords
{
    public string PolicyNumber { get; set; }
    //private string OriginalPolicyNumber { get; set; }
    public PolicyStatus Status { get; set; }
    public string BatchCount { get; set; }
    public string RunCount { get; set; }
    public bool RuntimeErrors { get; set; }
}

public class RuleReportTotal
{
    public string FileCount { get; set; }
    public string TotalRecords { get; set; }
    public string ObjectsPerFileForSplit { get; set; }
    public string InRuleMessageSize { get; set; }
    public string MaxRequestsAtOneTime { get; set; }
    public string Errors { get; set; }
    public string CompletedTime { get; set; }
}
public class PolicyInfo
{
    public string Name { get; set; }
    public string Value { get; set; }
}