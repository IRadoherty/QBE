﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using QBERuleRunner.Models;
using QBERuleRunner.Services;

namespace QBERuleRunner;

public interface IFileProcessing
{
    Task ProcessFiles();
}

public class FileProcessing : IFileProcessing
{
    private readonly AppSettings _appSettings;
    private readonly ILogger<FileProcessing> _logger;
    private readonly IUtilities _utilities;
    private readonly IExecutionService _executionService;

    public FileProcessing(ILogger<FileProcessing> logger, IUtilities utilities, IExecutionService executionService)
    {
        _appSettings = Program.AppSettings;
        _logger = logger;
        _utilities = utilities;
        _executionService = executionService;
    }

    public async Task ProcessFiles()
    {
        _logger.LogInformation("Starting file processing.");
        await foreach (var jsonFile in _utilities.GetJsonSplitDirectory().GetFilesAsync())
        {
            var isoData = await ReadIsoDataFromFile(jsonFile);
            Variables.BatchCount++;
            await _executionService.WarmUpExecutionService(isoData.FirstOrDefault()!);
            await ProcessIsoData(isoData);
            await _executionService.WriteOutputFiles(jsonFile);
        }
    }

    private static async Task<List<Iso>> ReadIsoDataFromFile(FileSystemInfo jsonFile)
    {
        using StreamReader reader = new (jsonFile.FullName);
        var json = await reader.ReadToEndAsync();
        return JsonConvert.DeserializeObject<List<Iso>>(json)!;
    }
    private async Task ProcessIsoData(List<Iso> isoData)
    {
        List<Task> tasks = new();
        for (var i = 0; i < isoData.Count; i += _appSettings.InRuleMessageSize)
        {
            Variables.RunCount++;
            var rangeSize = Math.Min(_appSettings.InRuleMessageSize, isoData.Count - i);
            tasks.Add(_executionService.ApplyRules(isoData.GetRange(i, rangeSize), i, rangeSize));
        }

        Variables.PolicyCount += isoData.Count;
        await Task.WhenAll(tasks).ConfigureAwait(false);
    }
}